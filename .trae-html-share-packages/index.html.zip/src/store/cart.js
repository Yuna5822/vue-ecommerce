import { reactive, computed, watch } from 'vue'

/**
 * 购物车全局状态（轻量方案：reactive + localStorage 持久化）
 * 不引入 pinia，保持项目精简；数据驱动视图，任何组件操作后自动同步
 */
const state = reactive({
  list: JSON.parse(localStorage.getItem('cart') || '[]')
})

// 任何变更自动持久化
watch(
  () => state.list,
  (val) => localStorage.setItem('cart', JSON.stringify(val)),
  { deep: true }
)

/** 加入购物车 */
export function addToCart(goods, sku = '默认款', count = 1) {
  const item = state.list.find((i) => i.id === goods.id && i.sku === sku)
  if (item) {
    item.count += count
  } else {
    state.list.push({
      id: goods.id,
      title: goods.title,
      price: goods.price,
      img: goods.img,
      sku,
      count,
      checked: true
    })
  }
}

/** 更新数量 */
export function updateCount(id, sku, count) {
  const item = state.list.find((i) => i.id === id && i.sku === sku)
  if (item) item.count = count
}

/** 删除商品 */
export function removeFromCart(id, sku) {
  const idx = state.list.findIndex((i) => i.id === id && i.sku === sku)
  if (idx > -1) state.list.splice(idx, 1)
}

/** 切换勾选 */
export function toggleCheck(id, sku) {
  const item = state.list.find((i) => i.id === id && i.sku === sku)
  if (item) item.checked = !item.checked
}

/** 全选 / 反选 */
export function toggleCheckAll(checked) {
  state.list.forEach((i) => (i.checked = checked))
}

/** 清空已勾选商品（结算） */
export function clearChecked() {
  state.list = state.list.filter((i) => !i.checked)
}

// 派生数据
export const cartList = computed(() => state.list)
export const cartCount = computed(() => state.list.reduce((sum, i) => sum + i.count, 0))
export const checkedList = computed(() => state.list.filter((i) => i.checked))
export const checkedTotalPrice = computed(() =>
  checkedList.value.reduce((sum, i) => sum + i.price * i.count, 0)
)
export const isAllChecked = computed(
  () => state.list.length > 0 && state.list.every((i) => i.checked)
)
